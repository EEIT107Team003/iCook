package ecpay.payment.integration.config;

public class EcpayConfig {
	public final static String version = "2.0.0";
}
